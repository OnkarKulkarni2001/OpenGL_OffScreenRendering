#include "someFunctions.h"

int AddNumbers(int x, int y)
{
	int z = x + y;
	// asdlaksdjaskjvfgdf
	return z;
}

