
#include "someFunctions.h"

#include <Windows.h>

int main()
{
	int p = AddNumbers(8, 9);

//		MessageBoxW(
//			_In_opt_ HWND hWnd,
//			_In_opt_ LPCWSTR lpText,
//			_In_opt_ LPCWSTR lpCaption,
//			_In_ UINT uType);

//	MessageBox(NULL, L"Hey!", L"OK?", MB_OK);

	void* pMsgBox = GetProcAddress(NULL, "glTexture");

	pMsgBox(NULL, L"Hey!", L"OK?", MB_OK);

	glCompileShader();
	//pglCompileShader(

	return 0;
}



