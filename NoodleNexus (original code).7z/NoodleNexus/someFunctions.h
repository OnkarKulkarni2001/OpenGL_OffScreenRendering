#ifndef _SomeFunctions_HG_
#define _SomeFunctions_HG_

// Signature of the function
int AddNumbers(int x, int y);

// class
extern int x;
// templates

// NO CODE. Evah. 
// (unless it's in a template)
// (YOU almost NEVER 'need' a template)


#endif
